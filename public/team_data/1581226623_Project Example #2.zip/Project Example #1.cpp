#include<stdio.h>

int main(){
	printf("Binus University\n");
}
